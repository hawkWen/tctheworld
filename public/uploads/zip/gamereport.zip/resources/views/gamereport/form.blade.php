@extends('layouts.app')

@section('content')
 <p> Your Content Goes Here </p>
@stop